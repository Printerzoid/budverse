import { Box, Paper, Stack, Button, Typography } from "@mui/material";
import { FormEventHandler, FunctionComponent, useEffect, useState, useRef } from "react";
import { CHARACTER_PARTS } from "./questions";

interface Props {
  restart: () => void;
  answers: number[];
}

const Component: FunctionComponent<Props> = ({ restart, answers }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [images, setImages] = useState<HTMLImageElement[]>([]);

  const onFormSubmit: FormEventHandler<HTMLFormElement> = async (event) => {
    event.preventDefault();
    restart();
  };

  useEffect(() => {
    let newImages = [];
    for (let i = 0; i < CHARACTER_PARTS.length; i++) {
      let failed = false;
      for (const required of CHARACTER_PARTS[i].required) {
        if (answers[required.question] !== required.option) {
          failed = true;
          break;
        }
      }

      if (!failed) {
        let image = new Image(0, 0);
        image.src = CHARACTER_PARTS[i].image;
        newImages.push(image);
        image.onload = () => {
          setImages(images => [...images]);
        }
      }
    }

    setImages(newImages);
  }, [answers]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const context = canvas.getContext('2d');
    if (!context) return;

    canvas.width = 7500;
    canvas.height = 9000;

    context.fillStyle = '#00000000';
    context.fillRect(0, 0, context.canvas.width, context.canvas.height);

    for (const image of images) {
      context.drawImage(image, 0, 0, 7500, 9000);
    }
  }, [images]);

  return (
    <Box component="form" onSubmit={onFormSubmit} noValidate sx={{ height: "100%" }}>
      <Paper sx={{ p: { xs: 2, sm: 4 }, boxShadow: { xs: "none", sm: undefined }, height: { xs: "100%", sm: "auto" } }}>
        <Stack spacing={2}>
          <Typography variant="h3" gutterBottom>
            Created Character
          </Typography>
          <Box sx={{ display: "flex", flexDirction: "row", justifyContent: "center" }}>
            <canvas ref={canvasRef} />
          </Box>
          <Button variant="contained" type="submit">Restart</Button>
        </Stack>
      </Paper>
    </Box>
  );
}

export default Component;