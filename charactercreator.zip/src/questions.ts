import buttons_lips from "./assets/buttons_lips.png";
import cat_lips from "./assets/cat_lips.png";
import circle_blue_head from "./assets/circle_blue_head.png";
import circle_cyan_head from "./assets/circle_cyan_head.png";
import circle_gray_head from "./assets/circle_gray_head.png";
import circle_green_head from "./assets/circle_green_head.png";
import circle_nose from "./assets/circle_nose.png";
import circle_pink_head from "./assets/circle_pink_head.png";
import circle_purple_head from "./assets/circle_purple_head.png";
import circle_red_head from "./assets/circle_red_head.png";
import circle_yellow_head from "./assets/circle_yellow_head.png";
import clover_nose from "./assets/clover_nose.png";
import diamond_blue_head from "./assets/diamond_blue_head.png";
import diamond_cyan_head from "./assets/diamond_cyan_head.png";
import diamond_gray_head from "./assets/diamond_gray_head.png";
import diamond_green_head from "./assets/diamond_green_head.png";
import diamond_pink_head from "./assets/diamond_pink_head.png";
import diamond_purple_head from "./assets/diamond_purple_head.png";
import diamond_red_head from "./assets/diamond_red_head.png";
import diamond_yellow_head from "./assets/diamond_yellow_head.png";
import fangs_lips from "./assets/fangs_lips.png";
import heart_blue_head from "./assets/heart_blue_head.png";
import heart_cyan_head from "./assets/heart_cyan_head.png";
import heart_gray_head from "./assets/heart_gray_head.png";
import heart_green_head from "./assets/heart_green_head.png";
import heart_nose from "./assets/heart_nose.png";
import heart_pink_head from "./assets/heart_pink_head.png";
import heart_purple_head from "./assets/heart_purple_head.png";
import heart_red_head from "./assets/heart_red_head.png";
import heart_yellow_head from "./assets/heart_yellow_head.png";
import monster_lips from "./assets/monster_lips.png";
import oval_blue_head from "./assets/oval_blue_head.png";
import oval_cyan_head from "./assets/oval_cyan_head.png";
import oval_gray_head from "./assets/oval_gray_head.png";
import oval_green_head from "./assets/oval_green_head.png";
import oval_nose from "./assets/oval_nose.png";
import oval_pink_head from "./assets/oval_pink_head.png";
import oval_purple_head from "./assets/oval_purple_head.png";
import oval_red_head from "./assets/oval_red_head.png";
import oval_yellow_head from "./assets/oval_yellow_head.png";
import plump_lips from "./assets/plump_lips.png";
import rectangle_blue_head from "./assets/rectangle_blue_head.png";
import rectangle_cyan_head from "./assets/rectangle_cyan_head.png";
import rectangle_gray_head from "./assets/rectangle_gray_head.png";
import rectangle_green_head from "./assets/rectangle_green_head.png";
import rectangle_nose from "./assets/rectangle_nose.png";
import rectangle_pink_head from "./assets/rectangle_pink_head.png";
import rectangle_purple_head from "./assets/rectangle_purple_head.png";
import rectangle_red_head from "./assets/rectangle_red_head.png";
import rectangle_yellow_head from "./assets/rectangle_yellow_head.png";
import square_blue_head from "./assets/square_blue_head.png";
import square_cyan_head from "./assets/square_cyan_head.png";
import square_gray_head from "./assets/square_gray_head.png";
import square_green_head from "./assets/square_green_head.png";
import square_nose from "./assets/square_nose.png";
import square_pink_head from "./assets/square_pink_head.png";
import square_purple_head from "./assets/square_purple_head.png";
import square_red_head from "./assets/square_red_head.png";
import square_yellow_head from "./assets/square_yellow_head.png";
import star_nose from "./assets/star_nose.png";
import stitches_lips from "./assets/stitches_lips.png";
import triangle_nose from "./assets/triangle_nose.png";

export interface Question {
    prompt: string;
    options: string[];
}

export const CHARACTER_PARTS = [
    // Heads
    { required: [{ question: 0, option: 0 }, { question: 1, option: 0 }], image: oval_gray_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 0 }], image: circle_gray_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 0 }], image: heart_gray_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 0 }], image: square_gray_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 0 }], image: rectangle_gray_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 0 }], image: diamond_gray_head },

    { required: [{ question: 0, option: 0 }, { question: 1, option: 1 }], image: oval_red_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 1 }], image: circle_red_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 1 }], image: heart_red_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 1 }], image: square_red_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 1 }], image: rectangle_red_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 1 }], image: diamond_red_head },

    { required: [{ question: 0, option: 0 }, { question: 1, option: 2 }], image: oval_purple_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 2 }], image: circle_purple_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 2 }], image: heart_purple_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 2 }], image: square_purple_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 2 }], image: rectangle_purple_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 2 }], image: diamond_purple_head },

    { required: [{ question: 0, option: 0 }, { question: 1, option: 3 }], image: oval_cyan_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 3 }], image: circle_cyan_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 3 }], image: heart_cyan_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 3 }], image: square_cyan_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 3 }], image: rectangle_cyan_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 3 }], image: diamond_cyan_head },

    { required: [{ question: 0, option: 0 }, { question: 1, option: 4 }], image: oval_green_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 4 }], image: circle_green_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 4 }], image: heart_green_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 4 }], image: square_green_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 4 }], image: rectangle_green_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 4 }], image: diamond_green_head },

    { required: [{ question: 0, option: 0 }, { question: 1, option: 5 }], image: oval_blue_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 5 }], image: circle_blue_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 5 }], image: heart_blue_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 5 }], image: square_blue_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 5 }], image: rectangle_blue_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 5 }], image: diamond_blue_head },

    { required: [{ question: 0, option: 0 }, { question: 1, option: 6 }], image: oval_pink_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 6 }], image: circle_pink_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 6 }], image: heart_pink_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 6 }], image: square_pink_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 6 }], image: rectangle_pink_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 6 }], image: diamond_pink_head },

    { required: [{ question: 0, option: 0 }, { question: 1, option: 7 }], image: oval_yellow_head },
    { required: [{ question: 0, option: 1 }, { question: 1, option: 7 }], image: circle_yellow_head },
    { required: [{ question: 0, option: 2 }, { question: 1, option: 7 }], image: heart_yellow_head },
    { required: [{ question: 0, option: 3 }, { question: 1, option: 7 }], image: square_yellow_head },
    { required: [{ question: 0, option: 4 }, { question: 1, option: 7 }], image: rectangle_yellow_head },
    { required: [{ question: 0, option: 5 }, { question: 1, option: 7 }], image: diamond_yellow_head },

    // Noses
    { required: [{ question: 5, option: 0 }], image: "" },
    { required: [{ question: 5, option: 1 }], image: triangle_nose },
    { required: [{ question: 5, option: 2 }], image: circle_nose },
    { required: [{ question: 5, option: 3 }], image: rectangle_nose },
    { required: [{ question: 5, option: 4 }], image: square_nose },
    { required: [{ question: 5, option: 5 }], image: oval_nose },
    { required: [{ question: 5, option: 6 }], image: star_nose },
    { required: [{ question: 5, option: 7 }], image: heart_nose },
    { required: [{ question: 5, option: 8 }], image: clover_nose },

    // Lips
    { required: [{ question: 6, option: 0 }], image: buttons_lips },
    { required: [{ question: 6, option: 1 }], image: cat_lips },
    { required: [{ question: 6, option: 2 }], image: fangs_lips },
    { required: [{ question: 6, option: 3 }], image: monster_lips },
    { required: [{ question: 6, option: 4 }], image: plump_lips },
    { required: [{ question: 6, option: 5 }], image: stitches_lips },
]

export const QUESTIONS = [
    {
        prompt: "How are you currently feeling?",
        options: [
            "Scared",
            "Annoyed",
            "Envious",
            "Overwhelmed",
            "Sad",
            "Needy",
        ]
    },
    {
        prompt: "How do you comfort yourself?",
        options: [
            "A long cry",
            "Take a relaxing bath or shower",
            "Listen to music",
            "Do an indoor activity",
            "Do an outside activity",
            "Take a nap",
            "Seek loved ones for comfort",
            "Eat a favorite snack",
        ]
    },
    {
        prompt: "What's your biggest fear?",
        options: [
            "Disease",
            "Change",
            "Clowns",
            "Falling",
            "Insects",
            "Imperfection",
            "Darkness",
            "Aging",
            "Socializing",
            "Drowning",
            "Being alone",
        ]
    },
    {
        prompt: "What are you insecure about?",
        options: [
            "Not having friends",
            "Nothing",
            "My confidence",
            "My skills",
            "Depending on others",
            "Being unapproachable",
            "Comparing myself",
            "Being not good enough",
            "My intelligence",
            "Not being able to make others happy",
            "Judgment",
            "Overeating",
            "Over procrastinating",
        ]
    },
    {
        prompt: "What upsets you the most?",
        options: [
            "Being blamed for something I didn't do",
            "When loved ones are upset",
            "Being left out by friends",
            "Other people's opinions",
            "Getting rejected",
            "Disrespect from others",
            "People who don't listen",
            "A colleague not doing their work",
            "Not being told the truth",
            "Myself",
        ]
    },
    {
        prompt: "What are you thankful for?",
        options: [
            "My existance",
            "My close friends",
            "My partner",
            "My teachers",
            "My job",
            "My health",
            "My pet(s)",
            "My family",
            "My education"
        ]
    },
    {
        prompt: "What makes you happy?",
        options: [
            "Creating",
            "Physical affection",
            "Alone time",
            "Being around loved ones",
            "Treating myself",
            "Helping others",
        ]
    }
]